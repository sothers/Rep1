Source samples from Yaplex blog
=============

Source samples from my blog

Design and development by Alex Shapovalov, Senior [.NET Developer](https://yaplex.com ".NET Developer") in Toronto. Learn more about me from [.NET Developer resume](https://yaplex.com/resume ".NET developer resume").
