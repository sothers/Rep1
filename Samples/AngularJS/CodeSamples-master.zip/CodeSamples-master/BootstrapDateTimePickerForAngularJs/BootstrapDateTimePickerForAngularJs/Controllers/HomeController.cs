﻿using System.Web.Mvc;

namespace BootstrapDateTimePickerForAngularJs.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}