﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NG_MVC_FIltering.Controllers
{
    public class OrdersInfoController : Controller
    {
        // GET: Orders
        public ActionResult Index()
        {
            return View();
        }
    }
}