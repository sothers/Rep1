﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using DataAccessLayer;
using TestApp.Properties;
using System.Collections;
using System.Data.Common;
using System.Drawing;
using System.Text;
using System.Diagnostics;
using System.Configuration;
using System.Linq;

namespace TestApp
{
    public partial class FormDataLayerTest : Form
    {
        #region private fields

        /// <summary>
        /// Current application settings
        /// </summary>
        private Configuration _config;
        private string[] _sqlServerSettings;
        private DatabaseTypes _currentDatabaseType;

        private IDataLayer _dal;
        private DataTable _parameterTable;
        private const string NullText = "Null";
        private const string LineTerminatorStr = @"\***\";
        private string[] LineTerminator = { LineTerminatorStr };
        private Stopwatch _stopWatch;

        #endregion

        #region Constructor

        /// <summary>
        /// Inaitalize data and information in controls
        /// </summary>
        public FormDataLayerTest()
        {
            InitializeComponent();

            _config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);

            _currentDatabaseType = DatabaseTypes.None;

            // The calculation of width height slows too much display of results. Especially if the result is more than 1000 items
            //dgvResult.RowHeadersWidthSizeMode =
            //    DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            //dgvResult.ColumnHeadersHeightSizeMode =
            //    DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            //dgvResult.AutoSizeColumnsMode =
            //    DataGridViewAutoSizeColumnsMode.AllCells;

            // Create Data layer from .config settings
            // This is only for test
            _dal = DataLayer.GetInstance();
            _dal.Dispose();

            AddSqlServers(cbSqlServers, typeof(DatabaseTypes), cbSqlServers_SelectedIndexChanged, (int)DatabaseTypes.MSSql);

            InitailizeParameters();

            FillEnumToComboBox(typeof(CommandType), cbCommandType);

            _stopWatch = new Stopwatch();
            cbCustomActions.SelectedIndex = 0;

            tsLblLastOperationSatus.Text = String.Empty;
        }

        #endregion

        #region Initailice methods

        /// <summary>
        /// Initailize parameters information
        /// </summary>
        private void InitailizeParameters()
        {
            dgvParameters.AutoGenerateColumns = false;
            dgvParameters.RowHeadersWidthSizeMode =
                DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dgvParameters.ColumnHeadersHeightSizeMode =
                DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvParameters.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.AllCells;

            FillEnumToDGVComboBox(typeof(DbType), colParamsType);
            FillEnumToDGVComboBox(typeof(ParameterDirection), colParamsDirection);

            _parameterTable = new DataTable();

            DataColumn column;

            // parameterTable.Name
            column = new DataColumn();
            column.DataType = typeof(String);
            column.ColumnName = "Name";
            column.MaxLength = 50;
            column.AllowDBNull = false;
            column.DefaultValue = "ParameterName";
            _parameterTable.Columns.Add(column);

            // parameterTable.Type
            column = new DataColumn();
            column.DataType = typeof(DbType); //System.Type.GetType("System.Data.DbType");
            column.ColumnName = "Type";
            column.AllowDBNull = false;
            column.DefaultValue = DbType.String;
            _parameterTable.Columns.Add(column);

            // parameterTable.Name
            column = new DataColumn();
            column.DataType = typeof(String);
            column.ColumnName = "Value";
            column.AllowDBNull = true;
            _parameterTable.Columns.Add(column);

            // parameterTable.Type
            column = new DataColumn();
            column.DataType = typeof(ParameterDirection);
            column.ColumnName = "Direction";
            column.AllowDBNull = false;
            column.DefaultValue = ParameterDirection.Input;
            _parameterTable.Columns.Add(column);

            dgvParameters.DataSource = _parameterTable;
        }

        /// <summary>
        /// Fill existing SQL servers
        /// </summary>
        /// <param name="comboBox">Combo box control to fill</param>
        /// <param name="enumeration">Enumeration from get data</param>
        /// <param name="selectedIndexChanged">Event handler for selected index changed</param>
        /// <param name="defValue">First showed value</param>
        private void AddSqlServers(ComboBox comboBox, Type enumeration, EventHandler selectedIndexChanged, int defValue)
        {
            List<KeyValuePair<int, string>> enumData = GetEmumData(enumeration);

            // Remove None
            enumData.RemoveAt(0);

            KeyValuePair<int, string> selected = enumData.SingleOrDefault(entry => entry.Key == defValue);

            comboBox.DataSource = enumData;
            comboBox.ValueMember = "Key";
            comboBox.DisplayMember = "Value";

            comboBox.SelectedIndexChanged += new EventHandler(selectedIndexChanged);

            comboBox.SelectedItem = selected;

            // Raise event
            selectedIndexChanged(comboBox, EventArgs.Empty);
        }

        #endregion

        #region private fill data from enum

        /// <summary>
        /// Get enum data and strore in list
        /// </summary>
        /// <param name="enumeration">Enumeration type</param>
        /// <returns>Collection with values</returns>
        private List<KeyValuePair<int, string>> GetEmumData(Type enumeration)
        {
            KeyValuePair<int, string> keyValue;
            List<KeyValuePair<int, string>> enumData = new List<KeyValuePair<int, string>>();

            string[] values = Enum.GetNames(enumeration);
            Array key = Enum.GetValues(enumeration);

            for (int i = 0; i < values.Length; i++)
            {
                keyValue = new KeyValuePair<int, string>((int)key.GetValue(i), values[i]);
                enumData.Add(keyValue);
            }

            return enumData;
        }

        /// <summary>
        /// Fill data to Combo box
        /// </summary>
        /// <param name="enumeration">Enumeration type</param>
        /// <param name="comboBox">Combo box to filled</param>
        private void FillEnumToComboBox(Type enumeration, ComboBox comboBox)
        {
            comboBox.Items.Clear();
            comboBox.DropDownStyle = ComboBoxStyle.DropDownList;

            comboBox.DataSource = GetEmumData(enumeration);
            comboBox.ValueMember = "Key";
            comboBox.DisplayMember = "Value";
        }

        /// <summary>
        /// Fill data to DataGridView Combo box
        /// </summary>
        /// <param name="enumeration">Enumeration type</param>
        /// <param name="comboBox">Combo box to filled</param>
        private void FillEnumToDGVComboBox(Type enumeration, DataGridViewComboBoxColumn comboBox)
        {
            comboBox.Items.Clear();

            comboBox.DataSource = GetEmumData(enumeration);
            comboBox.ValueMember = "Key";
            comboBox.DisplayMember = "Value";
        }
        #endregion

        #region private SetStatuses methods

        /// <summary>
        /// Add current Connection status
        /// </summary>
        private void DataBaseInfo()
        {
            if (_dal.Connected)
            {
                tsLblConnectStatus.Image = TestApp.Properties.Resources.OK;
                tsLblConnectStatus.Text = "Connected";
            }
            else
            {
                tsLblConnectStatus.Image = TestApp.Properties.Resources.NoAction;
                tsLblConnectStatus.Text = "Disconnected";
            }

            tsLblLastOperationSatus.Image = TestApp.Properties.Resources.NoAction;
            tsLblLastOperationSatus.Text = "None";
        }

        /// <summary>
        /// Add result information
        /// </summary>
        private void BaseResultInfo()
        {
            _stopWatch.Stop();

            DataBaseInfo();

            if (_dal.IsError)
            {
                tsLblLastOperationSatus.Text = "Error";
                tsLblLastOperationSatus.Image = TestApp.Properties.Resources.NoAction;

                tbResultMessage.ForeColor = Color.Red;
                tbResultMessage.Text = "Operation status: Error";

                if (String.IsNullOrEmpty(tbResultMessage.Text))
                    tbResultMessage.ForeColor = Color.Red;
                else
                    tbResultMessage.Text += Environment.NewLine;

                tbResultMessage.Text += "Error: " + _dal.LastError;
            }
            else
            {
                tsLblLastOperationSatus.Text = "Successfully";
                tbResultMessage.ForeColor = lblSQL.ForeColor;
                tbResultMessage.Text = "Operation status: Successfully";
                tsLblLastOperationSatus.Image = TestApp.Properties.Resources.OK;

                // Add parameters result
                AddResultParams();
            }


            if (_dal.Connected)
            {
                tbResultMessage.Text += Environment.NewLine;
                tbResultMessage.Text += String.Format("Execution time: {0}", _stopWatch.Elapsed);
            }
        }

        /// <summary>
        /// Add row affected info
        /// </summary>
        /// <param name="rowsAffected">Number of row affected</param>
        private void RowsAffected(int rowsAffected)
        {
            tbResultMessage.Text += Environment.NewLine;
            tbResultMessage.Text += String.Format("Rows affected: {0}", rowsAffected);
        }

        /// <summary>
        /// Add Table count info
        /// </summary>
        /// <param name="tableCount">Numbers of table</param>
        private void TableCount(int tableCount)
        {
            tbResultMessage.Text += Environment.NewLine;
            tbResultMessage.Text += String.Format("Table(s) count: {0}", tableCount);
        }

        /// <summary>
        /// Add result info
        /// </summary>
        /// <param name="result">Result</param>
        private void ExecutionResult(object result)
        {
            tbResultMessage.Text += Environment.NewLine;
            tbResultMessage.Text += String.Format("Result:" + Environment.NewLine + " {0}", result);
        }

        /// <summary>
        /// Add DataTable result
        /// </summary>
        /// <param name="result">DataTable result</param>
        private void ExecutionResult(DataTable result)
        {
            dgvResult.DataSource = result;
        }

        /// <summary>
        /// Add DataSet result
        /// </summary>
        /// <param name="dataSet">Add DataSet result</param>
        private void ExecutionResult(DataSet dataSet)
        {
            if (dataSet == null || dataSet.Tables.Count == 0)
                return;

            for (int i = 0; i < dataSet.Tables.Count; i++)
                cbTables.Items.Add(dataSet.Tables[i]);

            cbTables.Enabled = cbTables.Items.Count > 1;
            cbTables.DisplayMember = "TableName";
            cbTables.SelectedIndex = 0;
        }

        /// <summary>
        /// Add List result
        /// </summary>
        /// <param name="result">List result</param>
        private void ExecutionResult(List<IdValueEntity> result)
        {
            dgvResult.DataSource = result;
        }

        #endregion

        #region private Execute voids

        /// <summary>
        /// Execute non query
        /// </summary>
        /// <param name="sender">Object sender</param>
        /// <param name="e">Parameters</param>
        private void btnExecNonQuery_Click(object sender, EventArgs e)
        {
            PreExecute();

            //_dal.Sql =
            //    "   INSERT INTO Customers"
            //    + "       ( CustomerID,  CompanyName)"
            //    + " VALUES"
            //    + "       (@CustomerID, @CompanyName)";
            //_dal.AddParameter("CustomerID", "TESTC");
            //_dal.AddParameter("CompanyName", "Test company name");

            int rowsAffected = _dal.ExecuteNonQuery();

            BaseResultInfo();

            RowsAffected(rowsAffected);
        }

        /// <summary>
        /// Execute scalar. Return only one result
        /// </summary>
        /// <param name="sender">Object sender</param>
        /// <param name="e">Parameters</param>
        private void btnExesScalar_Click(object sender, EventArgs e)
        {
            PreExecute();

            //_dal.Sql =
            //    "  SELECT EmployeeID, LastName"
            //    + "  FROM Employees"
            //    + " WHERE EmployeeID > @ID"
            //    + " ORDER BY LastName";
            //_dal.AddParameter("ID", 2, DbType.Int32);

            object o = _dal.ExecuteScalar();

            BaseResultInfo();

            ExecutionResult(o);
        }

        /// <summary>
        /// Execute DataReader.
        /// </summary>
        /// <param name="sender">Object sender</param>
        /// <param name="e">Parameters</param>
        private void btnExecDataReader_Click(object sender, EventArgs e)
        {
            PreExecute();

            IDataReader dr = null;
            dr = _dal.ExecuteDataReader();

            BaseResultInfo();

            IdValueEntity result = CollectData(dr);

            if (result == null)
                return;

            RowsAffected(result.Id);

            ExecutionResult(result.Value);
        }

        /// <summary>
        /// Execute table and view table in DataGridView
        /// </summary>
        /// <param name="sender">Object sender</param>
        /// <param name="e">Parameters</param>
        private void btnExecTable_Click(object sender, EventArgs e)
        {
            PreExecute();

            DataTable dt = null;
            dt = _dal.ExecuteDataTable();

            BaseResultInfo();

            RowsAffected(dt == null ? 0 : dt.Rows.Count);

            ExecutionResult(dt);
        }

        /// <summary>
        /// Execute DataSet and view in DataGridView
        /// </summary>
        /// <param name="sender">Object sender</param>
        /// <param name="e">Parameters</param>
        private void btnExecDS_Click(object sender, EventArgs e)
        {
            PreExecute();

            DataSet ds = _dal.ExecuteDataSet();

            BaseResultInfo();

            TableCount(ds == null ? 0 : ds.Tables.Count);

            ExecutionResult(ds);
        }

        /// <summary>
        /// Execute and fill data entity and view in DataGridView
        /// </summary>
        /// <param name="sender">Object sender</param>
        /// <param name="e">Parameters</param>
        private void btnExecAndFill_Click(object sender, EventArgs e)
        {
            PreExecute();

            List<IdValueEntity> dep = null;
            dep = _dal.ExecuteAndFillList<IdValueEntity>();

            BaseResultInfo();

            RowsAffected(dep == null ? 0 : dep.Count);

            ExecutionResult(dep);
        }

        /// <summary>
        /// Execute specific example
        /// </summary>
        /// <param name="sender">Object sender</param>
        /// <param name="e">Parameters</param>
        private void btnExecCustom_Click(object sender, EventArgs e)
        {
            PreExecute();

            int index = cbCustomActions.SelectedIndex;
            if (index == -1)
                return;
            switch (index)
            {
                case 0:
                    ExecuteDataTableSPMsSQL();
                    break;
                case 1:
                    ExecuteDataSetSPMsSQL();
                    break;
                case 2:
                    ExecuteDataSetNullParamSPMsSQL();
                    break;
                case 3:
                    ExecuteAddParametersMsSQL();
                    break;
                case 4:
                    ExecuteAndFillListRenamedColumn();
                    break;
                case 5:
                    ExecuteAndFillRenamedColumn();
                    break;
                case 6:
                    UpdateExcelSheetCell();
                    break;
                default:
                    throw new ArgumentException(" The action '" + cbCustomActions.SelectedText + "' not defined.");
            }
        }

        /// <summary>
        /// This is an example to work with SP in receiving as a result of one table with data.
        /// </summary>
        private void ExecuteDataTableSPMsSQL()
        {
            _dal.Sql = "CustOrderHist";
            _dal.CommandType = CommandType.StoredProcedure;

            _dal.AddParameter("CustomerID", "ALFKI");

            DataTable dt = _dal.ExecuteDataTable();

            BaseResultInfo();

            RowsAffected(dt == null ? 0 : dt.Rows.Count);

            ExecutionResult(dt);
        }

        private void ExecuteDataSetSPMsSQL()
        {
            // This is for CommandType.Text
            //_dal.Sql = " EXEC @Result = SelInvoiceOrder @EmployeeID, @OrderID, @EmployeeCount OUTPUT, @OrderCount OUTPUT";
            _dal.Sql = "SelInvoiceOrder";
            _dal.CommandType = CommandType.StoredProcedure;

            // ParameterDirection of ReturnValue must be specified before the other parameters.
            // http://msdn.microsoft.com/en-us/library/59x02y99(VS.71).aspx
            IDbDataParameter ret = _dal.AddParameter("RETURN_VALUE", DbType.Int32, ParameterDirection.ReturnValue);
            // This is for CommandType.Text
            //IDbDataParameter ret = _dal.AddParameter("Result", DbType.Int32, ParameterDirection.Output);

            _dal.AddParameter("EmployeeID", 1, DbType.Int32, ParameterDirection.Input);

            _dal.AddParameter("OrderID", 10248, DbType.Int32, ParameterDirection.Input);

            // Add parameters which will later be read a output values
            IDbDataParameter outEmployeeCount = _dal.AddParameter("EmployeeCount", DbType.Int32, ParameterDirection.Output);
            IDbDataParameter outOrderCount = _dal.AddParameter("OrderCount", DbType.Int32, ParameterDirection.Output);

            DataSet ds = _dal.ExecuteDataSet();

            BaseResultInfo();

            TableCount(ds == null ? 0 : ds.Tables.Count);

            ExecutionResult(ds);

            // Reading the results of the parameters
            int retValue = ret.Value == DBNull.Value ? 0 : (int)ret.Value;
            int outInvCount = outEmployeeCount.Value == DBNull.Value ? 0 : (int)outEmployeeCount.Value;
            int outOrdCount = outOrderCount.Value == DBNull.Value ? 0 : (int)outOrderCount.Value;
        }

        private void ExecuteDataSetNullParamSPMsSQL()
        {
            _dal.Sql = "SelInvoiceOrder";
            _dal.CommandType = CommandType.StoredProcedure;

            // ParameterDirection of ReturnValue must be specified before the other parameters.
            // http://msdn.microsoft.com/en-us/library/59x02y99(VS.71).aspx
            IDbDataParameter ret = _dal.AddParameter("RETURN_VALUE", DbType.Int32, ParameterDirection.ReturnValue);

            // Set parameter - null
            _dal.AddParameter("EmployeeID", DBNull.Value, DbType.Int32, ParameterDirection.Input);

            // Set parameter - null
            _dal.AddParameter("OrderID", DBNull.Value, DbType.Int32, ParameterDirection.Input);

            // Add parameters which will later be read a output values
            IDbDataParameter outInvoiceCount = _dal.AddParameter("EmployeeCount", DbType.Int32, ParameterDirection.Output);
            IDbDataParameter outOrderCount = _dal.AddParameter("OrderCount", DbType.Int32, ParameterDirection.Output);

            DataSet ds = _dal.ExecuteDataSet();

            BaseResultInfo();

            TableCount(ds == null ? 0 : ds.Tables.Count);

            ExecutionResult(ds);

            // Reading the results of the parameters
            int retValue = ret.Value == DBNull.Value ? 0 : (int)ret.Value;
            int outInvCount = outInvoiceCount.Value == DBNull.Value ? 0 : (int)outInvoiceCount.Value;
            int outOrdCount = outOrderCount.Value == DBNull.Value ? 0 : (int)outOrderCount.Value;
        }

        private void ExecuteAddParametersMsSQL()
        {
            _dal.Sql =
                "  SELECT ShipName, ShipAddress, ShipCity, ShipRegion, ShipPostalCode, ShipCountry, CustomerID, CustomerName, Address, City, Region, PostalCode,"
                + "       Country, Salesperson, OrderID, OrderDate, RequiredDate, ShippedDate, ShipperName, ProductID, ProductName, UnitPrice, Quantity, Discount,"
                + "       ExtendedPrice, Freight"
                + "  FROM Invoices"
                + " WHERE (CustomerID = @CustomerID) AND (OrderID = @OrderID)";
            // CommandType.Text is default
            //_dal.CommandType = CommandType.Text;

            _dal.AddParameters("VICTE", 10251);

            DataTable dt = _dal.ExecuteDataTable();

            BaseResultInfo();

            RowsAffected(dt == null ? 0 : dt.Rows.Count);

            ExecutionResult(dt);
        }

        private void ExecuteAndFillListRenamedColumn()
        {
            _dal.Sql =
                "  SELECT OrderID AS ID, ProductID, ProductName AS Value, UnitPrice"
                + "  FROM [dbo].[Order Details Extended]";
            // CommandType.Text is default
            //_dal.CommandType = CommandType.Text;
            List<IdValueEntity> list = null;
            // Test performance
            //for (int i = 0; i < 300; i++)
            list = _dal.ExecuteAndFillList<IdValueEntity>();

            BaseResultInfo();

            RowsAffected(list == null ? 0 : list.Count);

            ExecutionResult(list);
        }

        private void ExecuteAndFillRenamedColumn()
        {
            _dal.Sql =
                "  SELECT OrderID AS ID, ProductID, ProductName AS Value, UnitPrice"
                + "  FROM [dbo].[Order Details Extended]";
            // CommandType.Text is default
            //_dal.CommandType = CommandType.Text;

            IdValueEntity ent = _dal.ExecuteAndFill<IdValueEntity>();

            BaseResultInfo();

            RowsAffected(ent == null ? 0 : 1);

            // Add to the list can only be shown in the table
            List<IdValueEntity> list = new List<IdValueEntity>();
            list.Add(ent);

            ExecutionResult(list);
        }

        private void UpdateExcelSheetCell()
        {
            _dal = DataLayer.GetInstance(DatabaseTypes.OleDB);
            
            _dal.ConnectionString =
                @"Provider=Microsoft.Jet.OLEDB.4.0;"
                + "Data Source="
                // Excel file name
                + "ExcelWorksheet.xls"
                + ";Extended Properties=\"Excel 8.0;HDR=NO;\"";
            
            string sheetName = "Sheet1";
            string cell = "D2";
            _dal.Sql =
                " UPDATE [" + sheetName + "$" + cell + ":" + cell + "]"
                + " SET F1 = :value";
            _dal.AddParameter("value", 55, DbType.Int32);

            int rowsAffected = _dal.ExecuteNonQuery();

            BaseResultInfo();

            RowsAffected(rowsAffected);
        }

        #endregion

        #region private support methods

        private void SaveServerSettings(DatabaseTypes dbType)
        {
            if (dbType != DatabaseTypes.None)
            {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < _sqlServerSettings.Length; i++)
                    sb.Append(_sqlServerSettings[i] + LineTerminatorStr);

                _config.AppSettings.Settings[_currentDatabaseType.ToString()].Value = sb.ToString();

                _config.Save(ConfigurationSaveMode.Modified);
            }
        }

        private void ClearResult()
        {
            cbTables.Items.Clear();
            cbTables.Enabled = false;

            dgvResult.DataSource = null;

            tbResultMessage.Clear();

            lvOutPrams.Items.Clear();
        }

        private IdValueEntity CollectData(IDataReader dr)
        {
            if (dr == null || dr.IsClosed)
                return null;

            IdValueEntity result = new IdValueEntity();

            StringBuilder sb = new StringBuilder();
            int rowCount = 0;
            while (dr.Read())
            {
                rowCount++;

                for (int i = 0; i < dr.FieldCount; i++)
                {
                    sb.AppendFormat("{0};", dr[i]);
                }
                sb.Append(Environment.NewLine);
            }
            dr.Dispose();

            result.Id = rowCount;
            result.Value = sb.ToString();

            return result;
        }

        private void AddResultParams()
        {
            IDataParameterCollection outValues = _dal.Parameters;
            lvOutPrams.Items.Clear();
            if (outValues == null || outValues.Count == 0)
                return;

            for (int i = 0; i < outValues.Count; i++)
            {
                DbParameter param = (DbParameter)outValues[i];

                if (param.Direction == ParameterDirection.Input)
                    continue;

                ListViewItem lvItem = new ListViewItem(param.ParameterName);
                lvItem.SubItems.Add((param.Value == DBNull.Value || param.Value == null) ? NullText : param.Value.ToString());
                lvItem.SubItems.Add(param.Direction.ToString());

                lvOutPrams.Items.Add(lvItem);
            }
        }

        private void PreExecute()
        {
            ClearResult();

            // Start watch
            _stopWatch.Reset();
            _stopWatch.Start();

            // Set Sql
            _dal.Sql = tbSQL.Text;
            _dal.CommandType = (CommandType)((KeyValuePair<int, string>)cbCommandType.SelectedItem).Key;

            // Add parameters
            if (_parameterTable == null || _parameterTable.Rows.Count == 0)
                return;

            for (int i = 0; i < _parameterTable.Rows.Count; i++)
            {
                DataRow dr = _parameterTable.Rows[i];
                IDbDataParameter param = _dal.AddParameter();
                param.ParameterName = dr["Name"].ToString();
                param.DbType = (DbType)(int)dr["Type"];

                ParameterDirection direction = (ParameterDirection)(int)dr["Direction"];
                if (direction != ParameterDirection.Output || direction != ParameterDirection.ReturnValue)
                    param.Value = dr["Value"];

                param.Direction = direction;
            }
        }

        #endregion

        #region private Controls event handler

        private void frmDataLayerTest_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (_dal != null)
            {
                _dal.Close();
                _dal.Dispose();
            }
        }

        private void cbTables_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbTables.Items.Count == 0 || cbTables.SelectedItem == null)
                return;

            DataTable dt = (DataTable)cbTables.SelectedItem;

            dgvResult.DataSource = null;
            dgvResult.DataSource = dt;
        }

        private void cbSqlServers_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox cb = sender as ComboBox;
            if (cb.SelectedItem == null)
                return;

            DatabaseTypes dbType = (DatabaseTypes)((KeyValuePair<int, string>)cb.SelectedItem).Key;

            SaveServerSettings(_currentDatabaseType);

            string dbTypeContent = _config.AppSettings.Settings[((KeyValuePair<int, string>)cb.SelectedItem).Value].Value;

            _sqlServerSettings = new string[2];
            if (!String.IsNullOrEmpty(dbTypeContent))
                _sqlServerSettings = dbTypeContent.Split(LineTerminator, StringSplitOptions.RemoveEmptyEntries);

            string connStr = String.Empty;
            string sql = String.Empty;

            if (_sqlServerSettings != null && _sqlServerSettings.Length > 0)
                connStr = _sqlServerSettings[0];

            if (_sqlServerSettings != null && _sqlServerSettings.Length > 1)
                sql = _sqlServerSettings[1];

            // Stop fire event OnTextChanged
            //tbConnStr.TextChanged -= new EventHandler(tbConnectionString_TextChanged);
            tbConnStr.Text = connStr;
            //tbConnStr.TextChanged += new EventHandler(tbConnectionString_TextChanged);

            tbSQL.Text = sql;

            // Return data layer
            _dal = DataLayer.GetInstance(dbType, connStr, true);

            // Add Error event handler
            // Not handling here.
            //if (DataLayer.IsNewInstance)
            //    _dal.DatabaseError += new DatabaseErrorEventHandler(DataLayer_DatabaseError);

            ClearResult();
            DataBaseInfo();

            _currentDatabaseType = dbType;
        }

        private void btnGetParams_Click(object sender, EventArgs e)
        {
            _parameterTable.Clear();
            string sql = tbSQL.Text;

            if (String.IsNullOrEmpty(sql))
                return;

            bool addReturnValue = sql.TrimStart().StartsWith("EXEC") && _dal.DatabaseType == DatabaseTypes.MSSql;

            if (addReturnValue)
                _parameterTable.Rows.Add("Return", DbType.Int32, null, ParameterDirection.ReturnValue);

            int startIndex = 0;
            while ((startIndex = sql.IndexOf(_dal.ParameterPrefix, startIndex, StringComparison.OrdinalIgnoreCase)) > -1)
            {
                startIndex++;
                int endIndex = sql.IndexOfAny(Constants.SqlDivider(), startIndex);
                string paramName = sql.Substring(startIndex, endIndex - startIndex);

                _parameterTable.Rows.Add(paramName, DbType.String, null, ParameterDirection.Input);
            }
        }

        private void tbConnStr_TextChanged(object sender, EventArgs e)
        {
            if (_sqlServerSettings != null && _sqlServerSettings.Length > 0)
                _sqlServerSettings[0] = tbConnStr.Text;
        }

        private void tbSQL_TextChanged(object sender, EventArgs e)
        {
            if (_sqlServerSettings != null && _sqlServerSettings.Length > 1)
                _sqlServerSettings[1] = tbSQL.Text;
        }

        #endregion
    }
}
