﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Linq.Mapping;

namespace TestApp
{
    public sealed class IdValueEntity
    {
        public Int32 Id { get; set; }
        public string Value { get; set; }
    }

    public class KeyValueEntity<K, V>
    {
        private K _k;
        private V _v;

        public K Key
        { get { return _k; } }

        public V Value
        { get { return _v; } }

        public KeyValueEntity(K key, V value)
        {
            _k = key;
            _v = value;
        }
    }
}
