﻿namespace TestApp
{
    partial class FormDataLayerTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormDataLayerTest));
            this.btnExecTable = new System.Windows.Forms.Button();
            this.lblSQL = new System.Windows.Forms.Label();
            this.tbSQL = new System.Windows.Forms.TextBox();
            this.btnExecScalar = new System.Windows.Forms.Button();
            this.btnExecNonQuery = new System.Windows.Forms.Button();
            this.btnExecDS = new System.Windows.Forms.Button();
            this.btnExecAndFill = new System.Windows.Forms.Button();
            this.btnExecCustom = new System.Windows.Forms.Button();
            this.tsButtons = new System.Windows.Forms.ToolStrip();
            this.tsLblSqlServer = new System.Windows.Forms.ToolStripLabel();
            this.tsLblConnStr = new System.Windows.Forms.ToolStripLabel();
            this.cbSqlServers = new System.Windows.Forms.ComboBox();
            this.tbConnStr = new System.Windows.Forms.TextBox();
            this.sbStaus = new System.Windows.Forms.StatusStrip();
            this.tsLblConnectStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsLblLastOperation = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsLblLastOperationSatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.gbResult = new System.Windows.Forms.GroupBox();
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.dgvResult = new System.Windows.Forms.DataGridView();
            this.tbResultMessage = new System.Windows.Forms.TextBox();
            this.lvOutPrams = new System.Windows.Forms.ListView();
            this.lvOutParmsColName = new System.Windows.Forms.ColumnHeader();
            this.lvOutParmsColValue = new System.Windows.Forms.ColumnHeader();
            this.lvOutParmsColDirection = new System.Windows.Forms.ColumnHeader();
            this.lblResultTables = new System.Windows.Forms.Label();
            this.cbTables = new System.Windows.Forms.ComboBox();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.btnGetParams = new System.Windows.Forms.Button();
            this.cbCustomActions = new System.Windows.Forms.ComboBox();
            this.dgvParameters = new System.Windows.Forms.DataGridView();
            this.colParamsName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colParamsType = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.colParamsValue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colParamsDirection = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.lblParameterText = new System.Windows.Forms.Label();
            this.lblCommandTypeText = new System.Windows.Forms.Label();
            this.cbCommandType = new System.Windows.Forms.ComboBox();
            this.btnExecDataReader = new System.Windows.Forms.Button();
            this.tsButtons.SuspendLayout();
            this.sbStaus.SuspendLayout();
            this.gbResult.SuspendLayout();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvParameters)).BeginInit();
            this.SuspendLayout();
            // 
            // btnExecTable
            // 
            this.btnExecTable.Location = new System.Drawing.Point(280, 167);
            this.btnExecTable.Name = "btnExecTable";
            this.btnExecTable.Size = new System.Drawing.Size(75, 23);
            this.btnExecTable.TabIndex = 13;
            this.btnExecTable.Text = "Exec Table";
            this.btnExecTable.UseVisualStyleBackColor = true;
            this.btnExecTable.Click += new System.EventHandler(this.btnExecTable_Click);
            // 
            // lblSQL
            // 
            this.lblSQL.AutoSize = true;
            this.lblSQL.Location = new System.Drawing.Point(3, 28);
            this.lblSQL.Name = "lblSQL";
            this.lblSQL.Size = new System.Drawing.Size(31, 13);
            this.lblSQL.TabIndex = 3;
            this.lblSQL.Text = "SQL:";
            // 
            // tbSQL
            // 
            this.tbSQL.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tbSQL.Location = new System.Drawing.Point(6, 44);
            this.tbSQL.Multiline = true;
            this.tbSQL.Name = "tbSQL";
            this.tbSQL.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbSQL.Size = new System.Drawing.Size(361, 78);
            this.tbSQL.TabIndex = 4;
            this.tbSQL.TextChanged += new System.EventHandler(this.tbSQL_TextChanged);
            // 
            // btnExecScalar
            // 
            this.btnExecScalar.Location = new System.Drawing.Point(91, 167);
            this.btnExecScalar.Name = "btnExecScalar";
            this.btnExecScalar.Size = new System.Drawing.Size(75, 23);
            this.btnExecScalar.TabIndex = 11;
            this.btnExecScalar.Text = "Exec Scalar";
            this.btnExecScalar.UseVisualStyleBackColor = true;
            this.btnExecScalar.Click += new System.EventHandler(this.btnExesScalar_Click);
            // 
            // btnExecNonQuery
            // 
            this.btnExecNonQuery.Location = new System.Drawing.Point(10, 167);
            this.btnExecNonQuery.Name = "btnExecNonQuery";
            this.btnExecNonQuery.Size = new System.Drawing.Size(75, 23);
            this.btnExecNonQuery.TabIndex = 10;
            this.btnExecNonQuery.Text = "Exec N Qry";
            this.btnExecNonQuery.UseVisualStyleBackColor = true;
            this.btnExecNonQuery.Click += new System.EventHandler(this.btnExecNonQuery_Click);
            // 
            // btnExecDS
            // 
            this.btnExecDS.Location = new System.Drawing.Point(361, 167);
            this.btnExecDS.Name = "btnExecDS";
            this.btnExecDS.Size = new System.Drawing.Size(75, 23);
            this.btnExecDS.TabIndex = 14;
            this.btnExecDS.Text = "Exec DS";
            this.btnExecDS.UseVisualStyleBackColor = true;
            this.btnExecDS.Click += new System.EventHandler(this.btnExecDS_Click);
            // 
            // btnExecAndFill
            // 
            this.btnExecAndFill.Location = new System.Drawing.Point(442, 167);
            this.btnExecAndFill.Name = "btnExecAndFill";
            this.btnExecAndFill.Size = new System.Drawing.Size(75, 23);
            this.btnExecAndFill.TabIndex = 15;
            this.btnExecAndFill.Text = "Fill List";
            this.btnExecAndFill.UseVisualStyleBackColor = true;
            this.btnExecAndFill.Click += new System.EventHandler(this.btnExecAndFill_Click);
            // 
            // btnExecCustom
            // 
            this.btnExecCustom.Location = new System.Drawing.Point(741, 167);
            this.btnExecCustom.Name = "btnExecCustom";
            this.btnExecCustom.Size = new System.Drawing.Size(39, 23);
            this.btnExecCustom.TabIndex = 17;
            this.btnExecCustom.Text = "Exec";
            this.toolTip.SetToolTip(this.btnExecCustom, "Execute custom tests");
            this.btnExecCustom.UseVisualStyleBackColor = true;
            this.btnExecCustom.Click += new System.EventHandler(this.btnExecCustom_Click);
            // 
            // tsButtons
            // 
            this.tsButtons.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsLblSqlServer,
            this.tsLblConnStr});
            this.tsButtons.Location = new System.Drawing.Point(0, 0);
            this.tsButtons.Name = "tsButtons";
            this.tsButtons.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.tsButtons.Size = new System.Drawing.Size(792, 25);
            this.tsButtons.TabIndex = 0;
            this.tsButtons.Text = "toolStrip1";
            // 
            // tsLblSqlServer
            // 
            this.tsLblSqlServer.AutoSize = false;
            this.tsLblSqlServer.Margin = new System.Windows.Forms.Padding(0, 1, 124, 2);
            this.tsLblSqlServer.Name = "tsLblSqlServer";
            this.tsLblSqlServer.Size = new System.Drawing.Size(60, 22);
            this.tsLblSqlServer.Text = "SqlServer: ";
            // 
            // tsLblConnStr
            // 
            this.tsLblConnStr.Name = "tsLblConnStr";
            this.tsLblConnStr.Size = new System.Drawing.Size(95, 22);
            this.tsLblConnStr.Text = "Connection string:";
            // 
            // cbSqlServers
            // 
            this.cbSqlServers.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSqlServers.FormattingEnabled = true;
            this.cbSqlServers.Location = new System.Drawing.Point(70, 1);
            this.cbSqlServers.Name = "cbSqlServers";
            this.cbSqlServers.Size = new System.Drawing.Size(121, 21);
            this.cbSqlServers.TabIndex = 1;
            // 
            // tbConnStr
            // 
            this.tbConnStr.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tbConnStr.Location = new System.Drawing.Point(289, 2);
            this.tbConnStr.Name = "tbConnStr";
            this.tbConnStr.Size = new System.Drawing.Size(493, 20);
            this.tbConnStr.TabIndex = 2;
            this.tbConnStr.TextChanged += new System.EventHandler(this.tbConnStr_TextChanged);
            // 
            // sbStaus
            // 
            this.sbStaus.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsLblConnectStatus,
            this.tsLblLastOperation,
            this.tsLblLastOperationSatus});
            this.sbStaus.Location = new System.Drawing.Point(0, 463);
            this.sbStaus.Name = "sbStaus";
            this.sbStaus.Size = new System.Drawing.Size(792, 22);
            this.sbStaus.TabIndex = 19;
            this.sbStaus.Text = "statusStrip1";
            // 
            // tsLblConnectStatus
            // 
            this.tsLblConnectStatus.ImageTransparentColor = System.Drawing.Color.Fuchsia;
            this.tsLblConnectStatus.Name = "tsLblConnectStatus";
            this.tsLblConnectStatus.Padding = new System.Windows.Forms.Padding(0, 0, 20, 0);
            this.tsLblConnectStatus.Size = new System.Drawing.Size(120, 17);
            this.tsLblConnectStatus.Text = "tsLblConnectStatus";
            // 
            // tsLblLastOperation
            // 
            this.tsLblLastOperation.Name = "tsLblLastOperation";
            this.tsLblLastOperation.Size = new System.Drawing.Size(113, 17);
            this.tsLblLastOperation.Text = "Last operation status:";
            // 
            // tsLblLastOperationSatus
            // 
            this.tsLblLastOperationSatus.ImageTransparentColor = System.Drawing.Color.Fuchsia;
            this.tsLblLastOperationSatus.Name = "tsLblLastOperationSatus";
            this.tsLblLastOperationSatus.Size = new System.Drawing.Size(124, 17);
            this.tsLblLastOperationSatus.Text = "tsLblLastOperationSatus";
            // 
            // gbResult
            // 
            this.gbResult.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.gbResult.Controls.Add(this.splitContainer);
            this.gbResult.Controls.Add(this.lblResultTables);
            this.gbResult.Controls.Add(this.cbTables);
            this.gbResult.Location = new System.Drawing.Point(6, 196);
            this.gbResult.Name = "gbResult";
            this.gbResult.Size = new System.Drawing.Size(780, 264);
            this.gbResult.TabIndex = 18;
            this.gbResult.TabStop = false;
            this.gbResult.Text = "Result:";
            // 
            // splitContainer
            // 
            this.splitContainer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer.Location = new System.Drawing.Point(6, 43);
            this.splitContainer.Name = "splitContainer";
            this.splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.dgvResult);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(this.tbResultMessage);
            this.splitContainer.Panel2.Controls.Add(this.lvOutPrams);
            this.splitContainer.Size = new System.Drawing.Size(768, 215);
            this.splitContainer.SplitterDistance = 136;
            this.splitContainer.TabIndex = 32;
            // 
            // dgvResult
            // 
            this.dgvResult.AllowUserToAddRows = false;
            this.dgvResult.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvResult.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvResult.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvResult.Location = new System.Drawing.Point(0, 0);
            this.dgvResult.Name = "dgvResult";
            this.dgvResult.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvResult.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvResult.Size = new System.Drawing.Size(768, 136);
            this.dgvResult.TabIndex = 0;
            this.toolTip.SetToolTip(this.dgvResult, "Result table");
            // 
            // tbResultMessage
            // 
            this.tbResultMessage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbResultMessage.Location = new System.Drawing.Point(0, 0);
            this.tbResultMessage.Multiline = true;
            this.tbResultMessage.Name = "tbResultMessage";
            this.tbResultMessage.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbResultMessage.Size = new System.Drawing.Size(486, 75);
            this.tbResultMessage.TabIndex = 0;
            this.toolTip.SetToolTip(this.tbResultMessage, "Result message");
            // 
            // lvOutPrams
            // 
            this.lvOutPrams.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.lvOutParmsColName,
            this.lvOutParmsColValue,
            this.lvOutParmsColDirection});
            this.lvOutPrams.Dock = System.Windows.Forms.DockStyle.Right;
            this.lvOutPrams.FullRowSelect = true;
            this.lvOutPrams.GridLines = true;
            this.lvOutPrams.Location = new System.Drawing.Point(486, 0);
            this.lvOutPrams.MultiSelect = false;
            this.lvOutPrams.Name = "lvOutPrams";
            this.lvOutPrams.Size = new System.Drawing.Size(282, 75);
            this.lvOutPrams.TabIndex = 1;
            this.toolTip.SetToolTip(this.lvOutPrams, "Returning parameters");
            this.lvOutPrams.UseCompatibleStateImageBehavior = false;
            this.lvOutPrams.View = System.Windows.Forms.View.Details;
            // 
            // lvOutParmsColName
            // 
            this.lvOutParmsColName.Text = "Name";
            this.lvOutParmsColName.Width = 123;
            // 
            // lvOutParmsColValue
            // 
            this.lvOutParmsColValue.Text = "Value";
            this.lvOutParmsColValue.Width = 53;
            // 
            // lvOutParmsColDirection
            // 
            this.lvOutParmsColDirection.Text = "Direction";
            this.lvOutParmsColDirection.Width = 84;
            // 
            // lblResultTables
            // 
            this.lblResultTables.AutoSize = true;
            this.lblResultTables.Location = new System.Drawing.Point(6, 22);
            this.lblResultTables.Name = "lblResultTables";
            this.lblResultTables.Size = new System.Drawing.Size(42, 13);
            this.lblResultTables.TabIndex = 0;
            this.lblResultTables.Text = "Tables:";
            // 
            // cbTables
            // 
            this.cbTables.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cbTables.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbTables.FormattingEnabled = true;
            this.cbTables.Location = new System.Drawing.Point(54, 19);
            this.cbTables.Name = "cbTables";
            this.cbTables.Size = new System.Drawing.Size(720, 21);
            this.cbTables.TabIndex = 1;
            this.cbTables.SelectedIndexChanged += new System.EventHandler(this.cbTables_SelectedIndexChanged);
            // 
            // btnGetParams
            // 
            this.btnGetParams.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGetParams.Location = new System.Drawing.Point(371, 71);
            this.btnGetParams.Name = "btnGetParams";
            this.btnGetParams.Size = new System.Drawing.Size(23, 23);
            this.btnGetParams.TabIndex = 5;
            this.btnGetParams.Text = ">";
            this.toolTip.SetToolTip(this.btnGetParams, "Get parameters from query");
            this.btnGetParams.UseVisualStyleBackColor = true;
            this.btnGetParams.Click += new System.EventHandler(this.btnGetParams_Click);
            // 
            // cbCustomActions
            // 
            this.cbCustomActions.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbCustomActions.FormattingEnabled = true;
            this.cbCustomActions.Items.AddRange(new object[] {
            "Table from strored procedure CustOrderHist",
            "DataSet from 2 tables and 2 output params + returnig value",
            "DataSet from 2 tables 2 in param null and 2 out params + returnig value",
            "Test AddParamters method",
            "Fill list renamed columns",
            "Fill entity renamed columns",
            "Update Excel sheet cell"});
            this.cbCustomActions.Location = new System.Drawing.Point(523, 169);
            this.cbCustomActions.Name = "cbCustomActions";
            this.cbCustomActions.Size = new System.Drawing.Size(212, 21);
            this.cbCustomActions.TabIndex = 16;
            this.toolTip.SetToolTip(this.cbCustomActions, "Custom tests");
            // 
            // dgvParameters
            // 
            this.dgvParameters.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvParameters.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvParameters.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colParamsName,
            this.colParamsType,
            this.colParamsValue,
            this.colParamsDirection});
            this.dgvParameters.Location = new System.Drawing.Point(400, 44);
            this.dgvParameters.Name = "dgvParameters";
            this.dgvParameters.Size = new System.Drawing.Size(382, 105);
            this.dgvParameters.TabIndex = 7;
            // 
            // colParamsName
            // 
            this.colParamsName.DataPropertyName = "Name";
            this.colParamsName.HeaderText = "Name";
            this.colParamsName.MinimumWidth = 80;
            this.colParamsName.Name = "colParamsName";
            this.colParamsName.Width = 80;
            // 
            // colParamsType
            // 
            this.colParamsType.DataPropertyName = "Type";
            this.colParamsType.HeaderText = "Type";
            this.colParamsType.MinimumWidth = 80;
            this.colParamsType.Name = "colParamsType";
            this.colParamsType.Width = 80;
            // 
            // colParamsValue
            // 
            this.colParamsValue.DataPropertyName = "Value";
            dataGridViewCellStyle4.NullValue = "Null";
            this.colParamsValue.DefaultCellStyle = dataGridViewCellStyle4;
            this.colParamsValue.HeaderText = "Value";
            this.colParamsValue.MinimumWidth = 60;
            this.colParamsValue.Name = "colParamsValue";
            this.colParamsValue.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colParamsValue.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colParamsValue.Width = 60;
            // 
            // colParamsDirection
            // 
            this.colParamsDirection.DataPropertyName = "Direction";
            this.colParamsDirection.HeaderText = "Direction";
            this.colParamsDirection.MinimumWidth = 100;
            this.colParamsDirection.Name = "colParamsDirection";
            // 
            // lblParameterText
            // 
            this.lblParameterText.AutoSize = true;
            this.lblParameterText.Location = new System.Drawing.Point(412, 28);
            this.lblParameterText.Name = "lblParameterText";
            this.lblParameterText.Size = new System.Drawing.Size(63, 13);
            this.lblParameterText.TabIndex = 6;
            this.lblParameterText.Text = "Parameters:";
            // 
            // lblCommandTypeText
            // 
            this.lblCommandTypeText.AutoSize = true;
            this.lblCommandTypeText.Location = new System.Drawing.Point(3, 131);
            this.lblCommandTypeText.Name = "lblCommandTypeText";
            this.lblCommandTypeText.Size = new System.Drawing.Size(81, 13);
            this.lblCommandTypeText.TabIndex = 8;
            this.lblCommandTypeText.Text = "CommandType:";
            // 
            // cbCommandType
            // 
            this.cbCommandType.FormattingEnabled = true;
            this.cbCommandType.Location = new System.Drawing.Point(90, 128);
            this.cbCommandType.Name = "cbCommandType";
            this.cbCommandType.Size = new System.Drawing.Size(146, 21);
            this.cbCommandType.TabIndex = 9;
            // 
            // btnExecDataReader
            // 
            this.btnExecDataReader.Location = new System.Drawing.Point(172, 167);
            this.btnExecDataReader.Name = "btnExecDataReader";
            this.btnExecDataReader.Size = new System.Drawing.Size(102, 23);
            this.btnExecDataReader.TabIndex = 12;
            this.btnExecDataReader.Text = "Exec DataReader";
            this.btnExecDataReader.UseVisualStyleBackColor = true;
            this.btnExecDataReader.Click += new System.EventHandler(this.btnExecDataReader_Click);
            // 
            // FormDataLayerTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 485);
            this.Controls.Add(this.cbCustomActions);
            this.Controls.Add(this.btnExecDataReader);
            this.Controls.Add(this.cbCommandType);
            this.Controls.Add(this.lblCommandTypeText);
            this.Controls.Add(this.btnGetParams);
            this.Controls.Add(this.lblParameterText);
            this.Controls.Add(this.dgvParameters);
            this.Controls.Add(this.gbResult);
            this.Controls.Add(this.sbStaus);
            this.Controls.Add(this.tbConnStr);
            this.Controls.Add(this.cbSqlServers);
            this.Controls.Add(this.tsButtons);
            this.Controls.Add(this.btnExecCustom);
            this.Controls.Add(this.btnExecAndFill);
            this.Controls.Add(this.btnExecDS);
            this.Controls.Add(this.btnExecNonQuery);
            this.Controls.Add(this.btnExecScalar);
            this.Controls.Add(this.tbSQL);
            this.Controls.Add(this.lblSQL);
            this.Controls.Add(this.btnExecTable);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(800, 519);
            this.Name = "FormDataLayerTest";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Data Layer Test";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmDataLayerTest_FormClosed);
            this.tsButtons.ResumeLayout(false);
            this.tsButtons.PerformLayout();
            this.sbStaus.ResumeLayout(false);
            this.sbStaus.PerformLayout();
            this.gbResult.ResumeLayout(false);
            this.gbResult.PerformLayout();
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel2.ResumeLayout(false);
            this.splitContainer.Panel2.PerformLayout();
            this.splitContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvParameters)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnExecTable;
        private System.Windows.Forms.Label lblSQL;
        private System.Windows.Forms.TextBox tbSQL;
        private System.Windows.Forms.Button btnExecScalar;
        private System.Windows.Forms.Button btnExecNonQuery;
        private System.Windows.Forms.Button btnExecDS;
        private System.Windows.Forms.Button btnExecAndFill;
        private System.Windows.Forms.Button btnExecCustom;
        private System.Windows.Forms.ToolStrip tsButtons;
        private System.Windows.Forms.ToolStripLabel tsLblSqlServer;
        private System.Windows.Forms.ComboBox cbSqlServers;
        private System.Windows.Forms.ToolStripLabel tsLblConnStr;
        private System.Windows.Forms.TextBox tbConnStr;
        private System.Windows.Forms.StatusStrip sbStaus;
        private System.Windows.Forms.ToolStripStatusLabel tsLblConnectStatus;
        private System.Windows.Forms.GroupBox gbResult;
        private System.Windows.Forms.Label lblResultTables;
        private System.Windows.Forms.ComboBox cbTables;
        private System.Windows.Forms.ToolStripStatusLabel tsLblLastOperation;
        private System.Windows.Forms.ToolStripStatusLabel tsLblLastOperationSatus;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.DataGridView dgvParameters;
        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.DataGridView dgvResult;
        private System.Windows.Forms.TextBox tbResultMessage;
        private System.Windows.Forms.Label lblParameterText;
        private System.Windows.Forms.Button btnGetParams;
        private System.Windows.Forms.Label lblCommandTypeText;
        private System.Windows.Forms.ComboBox cbCommandType;
        private System.Windows.Forms.ListView lvOutPrams;
        private System.Windows.Forms.ColumnHeader lvOutParmsColName;
        private System.Windows.Forms.ColumnHeader lvOutParmsColValue;
        private System.Windows.Forms.ColumnHeader lvOutParmsColDirection;
        private System.Windows.Forms.DataGridViewTextBoxColumn colParamsName;
        private System.Windows.Forms.DataGridViewComboBoxColumn colParamsType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colParamsValue;
        private System.Windows.Forms.DataGridViewComboBoxColumn colParamsDirection;
        private System.Windows.Forms.Button btnExecDataReader;
        private System.Windows.Forms.ComboBox cbCustomActions;
    }
}

