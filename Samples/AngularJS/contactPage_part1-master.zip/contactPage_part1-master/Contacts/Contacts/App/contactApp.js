﻿//use 'strict';

var contactApp = angular.module('contactApp', ['ngRoute','ngResource']);

