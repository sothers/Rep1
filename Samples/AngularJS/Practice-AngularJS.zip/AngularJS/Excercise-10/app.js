var myApp = angular.module("myApp", {});


myApp.controller('myCtrl', function ($scope) {
    $scope.specialsList = {
        "Apple": { "name": "Apple", "priceInDollars": 1.50, "salePriceInDollars": "1", "specialDate": "Monday" },
        "Banana": { "name": "Banana", "priceInDollars": 2, "salePriceInDollars": "1.75", "specialDate": "Tuesday" },
        "Cherry": { "name": "Cherry", "priceInDollars": 2.3, "salePriceInDollars": "2", "specialDate": "Wednesday" },
        "Eggs": { "name": "Eggs", "priceInDollars": 2.12, "salePriceInDollars": "2", "specialDate": "Thursday" },
        "Figs": { "name": "Figs", "priceInDollars": 2.99, "salePriceInDollars": "2", "specialDate": "Friday" },
    };

    $scope.description = "This controllers contains a list of food specials.";
});

myApp.filter("dashes", function () {
        
    return function (text) {
        var chars = text.split("");
        return chars.join('-');
    }

});