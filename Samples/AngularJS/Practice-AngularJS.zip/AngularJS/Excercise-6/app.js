var myApp = angular.module("myApp", {});

myApp.factory('Share', function () {
    return {sharedMessage: "I am shared"};
})

myApp.controller('controllerA', function ($scope, Share) {
    $scope.value = "Hello from Controller A";
    //$scope.sharedValue = "value@A";
    $scope.sharedValue = Share;
});

myApp.controller("controllerB", function ($scope, Share) {    
    $scope.value = "Hello from Controller B";
    //$scope.sharedValue = "value@B";
    $scope.sharedValue = Share;
});