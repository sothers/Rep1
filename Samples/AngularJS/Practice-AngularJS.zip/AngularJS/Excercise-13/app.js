var myApp = angular.module("myApp",{});

myApp.controller('myCtrl', function($scope){
	
	$scope.theDate = Date.now();
	
});