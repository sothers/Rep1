var myApp = angular.module("myApp", {});


myApp.controller('AppCtrl', function($scope){
    $scope.model = {
        firstName: "James",
        lastName: "Smith"
    }

    $scope.testFunction = function (val1, val2) {
        window.alert("Hi from Angular");
    }
});