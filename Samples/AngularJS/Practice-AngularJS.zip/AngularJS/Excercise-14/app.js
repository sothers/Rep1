var myApp = angular.module("myApp",{});

myApp.controller('myController', function($scope){
	
	$scope.model = {firstName: 'Sachin', lastName: 'Ahiwale'}
	
});