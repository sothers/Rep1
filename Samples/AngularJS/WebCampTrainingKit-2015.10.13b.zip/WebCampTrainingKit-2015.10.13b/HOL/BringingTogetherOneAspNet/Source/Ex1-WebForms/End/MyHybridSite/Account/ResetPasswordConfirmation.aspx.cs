﻿using System.Web.UI;

namespace MyHybridSite.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}