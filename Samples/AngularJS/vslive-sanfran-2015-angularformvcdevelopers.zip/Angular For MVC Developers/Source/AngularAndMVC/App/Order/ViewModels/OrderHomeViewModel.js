﻿orderModule.controller("orderHomeViewModel", function ($scope, orderService, $http, $q, $routeParams, $window, $location, viewModelHelper) {

    $scope.viewModelHelper = viewModelHelper;
    $scope.orderService = orderService;


    var initialize = function () {

    }

    initialize();
});
