/*globals angular */
angular.module('demo',
  [
    'demo.demoController',
    'ui.bootstrap.datetimepicker'
  ])
  .config([
    function () {
      'use strict';

      // Configure the app here.

    }
  ]);
