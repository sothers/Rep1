var app;
(function (app) {
    (function (core) {
        /// <reference path="../../home/interfaces.ts" />
        (function (services) {
            var Utilities = (function () {
                function Utilities($window, globalsService) {
                    this.$window = $window;
                    this.globalsService = globalsService;
                    var that = this;
                    var pleaseWaitDiv = angular.element('<div class="modal" id="globalPleaseWaitDialog" data-backdrop="static" data-keyboard="false">' + '  <div class="modal-dialog">' + '    <div class="modal-content">' + '      <div class="modal-header">' + '         <h1>Processing...</h1>' + '      </div>' + '      <div class="modal-body" id="globallPleaseWaitDialogBody">' + '         <div class="progress progress-striped active">' + '           <div class="progress-bar" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%">' + '           </div>' + '         </div>' + '        <div class="progress-bar progress-striped active"><div class="bar" style="width: 100%;"></div></div>' + '      </div>' + '    </div>' + '  </div>' + '</div>');

                    var messageDiv = angular.element('<div class="modal" id="globalMessageDialog" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="true">' + '  <div class="modal-dialog">' + '    <div class="modal-content">' + '      <div class="modal-header">' + '        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>' + '        <h4 class="modal-title"></h4>' + '      </div>' + '      <div class="modal-body">' + '      </div>' + '      <div class="modal-footer">' + '       <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>' + '      </div>' + '    </div>' + '  </div>' + '</div>');

                    var resize = function (event) {
                        var dialog = angular.element('#' + event.data.name + ' .modal-dialog');
                        dialog.css('margin-top', (angular.element(that.$window).height() - dialog.height()) / 2 - parseInt(dialog.css('padding-top')));
                    };

                    var animate = function (event) {
                        var dialog = angular.element('#' + event.data.name + ' .modal-dialog');
                        dialog.css('margin-top', 0);
                        dialog.animate({ 'margin-top': (angular.element(that.$window).height() - dialog.height()) / 2 - parseInt(dialog.css('padding-top')) }, 'slow');
                        pleaseWaitDiv.off('shown.bs.modal', animate);
                    };

                    this.showPleaseWait = function () {
                        angular.element($window).on('resize', { name: 'globalPleaseWaitDialog' }, resize);
                        pleaseWaitDiv.on('shown.bs.modal', { name: 'globalPleaseWaitDialog' }, animate);
                        pleaseWaitDiv.modal();
                    };

                    this.hidePleaseWait = function () {
                        pleaseWaitDiv.modal('hide');
                        angular.element($window).off('resize', resize);
                    };

                    this.showMessage = function (content) {
                        angular.element($window).on('resize', { name: 'globalMessageDialog' }, resize);
                        messageDiv.find('.modal-title').text(globalsService.applicatioName);
                        messageDiv.find('.modal-body').text(content);
                        messageDiv.on('shown.bs.modal', { name: 'globalMessageDialog' }, animate);
                        messageDiv.modal();
                    };
                }
                return Utilities;
            })();

            angular.module('app.core.services.utilities', ['app.globalsModule']).factory('utilities', [
                '$window',
                'globalsService',
                function ($window, globalsService) {
                    return new Utilities($window, globalsService);
                }
            ]);
        })(core.services || (core.services = {}));
        var services = core.services;
    })(app.core || (app.core = {}));
    var core = app.core;
})(app || (app = {}));
//# sourceMappingURL=utilities.js.map
