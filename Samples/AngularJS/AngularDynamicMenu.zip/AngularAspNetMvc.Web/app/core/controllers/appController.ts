module app.core.controllers {
    export class CoreController {
    }
}