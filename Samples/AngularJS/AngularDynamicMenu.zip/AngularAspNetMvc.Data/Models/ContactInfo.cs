﻿
namespace AngularAspNetMvc.Data.Models
{
    public class ContactInfo
    {

        public int ContactId { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }
    }
}
