﻿using AngularAspNetMvc.DataAccess.Core.Repository;

namespace AngularAspNetMvc.DataAccess.Repository.Core
{
    public class Repository : WriteRepository<ContactsContext>
    {
    }
}
