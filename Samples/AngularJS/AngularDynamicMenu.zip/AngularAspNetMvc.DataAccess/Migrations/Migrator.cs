﻿using System.Data.Entity;

namespace AngularAspNetMvc.DataAccess.Migrations
{
    public class Migrator : MigrateDatabaseToLatestVersion<ContactsContext, Configuration>
    {
    }
}
