﻿namespace AngularAspNetMvc.Models.Core
{
    public abstract class EditableModel
    {
    }
}
