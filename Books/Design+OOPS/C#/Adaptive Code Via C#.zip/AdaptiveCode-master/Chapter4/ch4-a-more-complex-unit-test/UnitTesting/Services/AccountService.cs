﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ServiceInterfaces;

namespace Services
{
    public class AccountService : IAccountService
    {
        public void AddTransactionToAccount(string uniqueAccountName, decimal transactionAmount)
        {
            
        }
    }
}
