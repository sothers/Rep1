AdaptiveCode
============

Code samples to accompany the book Adaptive Code Via C#.
