﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DuckTyping
{
    public class Swan
    {
        public void Walk()
        {
            Console.WriteLine("The swan is walking.");
        }

        public void Swim()
        {
            Console.WriteLine("The swan can swim like a duck.");
        }

        public void Quack()
        {
            Console.WriteLine("The swan is quacking.");
        }
    }
}
