﻿namespace CustomControl
{
    partial class MyCustomControl
    {

    }
}
