﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassSample
{
    class Program
    {
        static void Main(string[] args)
        {
            //no output for this sample. See class Vertex3d
        }
    }
}
