﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FormattingAndParsing
{
    class FormattingAndParsing
    {

        static void Main(string[] args)
        {
            PrintNumbers.Run();

            ParseNumbers.Run();

            Console.ReadLine();
        }

        
    }
}
