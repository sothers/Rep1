namespace Kendo.Mvc.UI
{
    public interface IChartAxisDefaults : IChartAxis<double>
    {
    }
}