namespace Kendo.Mvc.Infrastructure
{
    public interface IJavaScriptSerializer
    {
        string Serialize(object value);
    }
}