namespace Kendo.Mvc.Infrastructure.Implementation
{
    public interface IValueNode
    {
        object Value
        {
            get;
        }
    }
}
