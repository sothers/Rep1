namespace Kendo.Mvc.UI.Html
{
    public interface IButtonHtmlBuilder
    {
        IHtmlNode ButtonTag();
    }
}