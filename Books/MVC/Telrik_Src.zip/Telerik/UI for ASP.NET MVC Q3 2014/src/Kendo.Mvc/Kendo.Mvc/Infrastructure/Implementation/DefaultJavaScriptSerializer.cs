using System.Web.Script.Serialization;

namespace Kendo.Mvc.Infrastructure
{
    public class DefaultJavaScriptSerializer : JavaScriptSerializer, IJavaScriptSerializer
    {
    }
}