namespace Kendo.Mvc.UI
{
    internal class ChartLineSerializer : ChartLineBaseSerializer
    {
        public ChartLineSerializer(ChartLine line)
            : base(line)
        {
        }
    }
}