namespace Kendo.Mvc.Infrastructure.Implementation.Expressions
{
    internal interface IMemberAccessToken
    {
    }
}