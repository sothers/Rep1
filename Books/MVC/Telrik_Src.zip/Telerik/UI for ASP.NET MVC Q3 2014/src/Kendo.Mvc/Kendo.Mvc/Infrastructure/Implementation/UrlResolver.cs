namespace Kendo.Mvc.Infrastructure.Implementation
{
    using System.Web;
    using System.Web.Mvc;
    using System.Web.Routing;

    using Extensions;

    public class UrlResolver : IUrlResolver
    {
        /// <summary>
        /// Returns the relative path for the specified virtual path.
        /// </summary>
        /// <param name="url">The URL.</param>
        /// <returns></returns>
        public string Resolve(string url)
        {
            HttpContextBase httpContext = new HttpContextWrapper(HttpContext.Current);
            RequestContext requestContext = httpContext.RequestContext();
            UrlHelper helper = new UrlHelper(requestContext);

            string query;

            url = StripQuery(url, out query);

            return helper.Content(url) + query;
        }

        private static string StripQuery(string path, out string query)
        {
            int queryIndex = path.IndexOf('?');

            if (queryIndex >= 0)
            {
                query = path.Substring(queryIndex);

                return path.Substring(0, queryIndex);
            }

            query = null;

            return path;
        }
    }
}