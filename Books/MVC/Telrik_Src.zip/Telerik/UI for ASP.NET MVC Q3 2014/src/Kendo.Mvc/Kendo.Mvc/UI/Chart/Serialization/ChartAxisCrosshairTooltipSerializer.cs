namespace Kendo.Mvc.UI
{
    internal class ChartAxisCrosshairTooltipSerializer : ChartTooltipBaseSerializer
    {
        public ChartAxisCrosshairTooltipSerializer(ChartAxisCrosshairTooltip chartTooltip)
            : base(chartTooltip)
        {
        }
    }
}