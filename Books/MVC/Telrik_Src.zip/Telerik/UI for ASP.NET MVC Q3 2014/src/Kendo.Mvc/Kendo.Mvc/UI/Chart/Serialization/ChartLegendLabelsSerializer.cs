namespace Kendo.Mvc.UI
{
    using System.Collections.Generic;
    using Kendo.Mvc.Extensions;
    using Kendo.Mvc.Infrastructure;

    internal class ChartLegendLabelsSerializer : ChartLabelsBase
    {
        public ChartLegendLabelsSerializer(ChartLegendLabels Labels)
            : base(Labels)
        {
        }
    }
}