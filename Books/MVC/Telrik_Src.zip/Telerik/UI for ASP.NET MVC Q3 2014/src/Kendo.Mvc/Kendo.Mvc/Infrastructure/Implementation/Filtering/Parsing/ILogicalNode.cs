namespace Kendo.Mvc.Infrastructure.Implementation
{
    public interface ILogicalNode
    {
        FilterCompositionLogicalOperator LogicalOperator
        {
            get;
        }
    }
}
