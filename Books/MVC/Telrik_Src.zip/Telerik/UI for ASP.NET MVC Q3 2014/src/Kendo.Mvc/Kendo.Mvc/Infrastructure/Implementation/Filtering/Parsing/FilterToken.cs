namespace Kendo.Mvc.Infrastructure.Implementation
{
    public class FilterToken
    {
        public FilterTokenType TokenType
        {
            get;
            set;
        }

        public string Value
        {
            get;
            set;
        }
    }
}