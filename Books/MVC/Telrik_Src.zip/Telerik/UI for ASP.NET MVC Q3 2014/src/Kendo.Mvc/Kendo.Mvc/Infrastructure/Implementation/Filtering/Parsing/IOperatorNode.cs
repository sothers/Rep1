namespace Kendo.Mvc.Infrastructure.Implementation
{
    public interface IOperatorNode
    {
        FilterOperator FilterOperator
        {
            get;
        }
    }
}
