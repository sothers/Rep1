namespace Kendo.Mvc.UI
{
    public interface IChartValueAxis : IChartAxisBase
    {
    }
}
