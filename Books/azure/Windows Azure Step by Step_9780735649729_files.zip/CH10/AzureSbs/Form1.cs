﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.WindowsAzure.StorageClient;
using Microsoft.WindowsAzure;
using System.Configuration;

namespace AzureSbs
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CloudStorageAccount account = this.CreateAccount();

            try
            {
                CloudTableClient tableClient = account.CreateCloudTableClient();
                tableClient.CreateTableIfNotExist("Books");

                TableServiceContext context = this.CreateContext(account);
                dataGridView1.DataSource = context.CreateQuery<Book>("Books").ToList();
            }
            catch (Exception ex)
            {
                // Exception handling
                // Be specific
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Book book = new Book();
            book.PartitionKey = "DEV";
            book.RowKey = Guid.NewGuid().ToString();

            book.Title = textBox1.Text;
            book.PublicationDate = DateTime.Now;

            CloudStorageAccount account = this.CreateAccount();
            TableServiceContext context = this.CreateContext(account);

            try
            {
                context.AddObject("Books", book);
                context.SaveChanges();

                dataGridView1.DataSource = context.CreateQuery<Book>("Books").ToList();
            }
            catch (Exception ex)
            {
                // Exception handling
                // Be specific
            }
        }

        private CloudStorageAccount CreateAccount()
        {
            CloudStorageAccount account = CloudStorageAccount.Parse(ConfigurationManager.AppSettings["DataConnectionString"]);
            return account;
        }

        private TableServiceContext CreateContext(CloudStorageAccount account)
        {

            String baseAddress = account.TableEndpoint.AbsoluteUri;
            StorageCredentials credentials = account.Credentials;

            return new TableServiceContext(baseAddress, credentials);
        }
    }
}
