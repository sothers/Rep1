﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.WindowsAzure.StorageClient;

namespace AzureSbs
{
    public class Book : TableServiceEntity
    {
        public String Title { get; set; }
        public DateTime PublicationDate { get; set; }
    }
}
