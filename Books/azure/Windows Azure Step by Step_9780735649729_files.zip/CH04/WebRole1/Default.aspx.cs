﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.WindowsAzure.ServiceRuntime;

namespace WebRole1
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_PreRender(object sender, EventArgs e)
        {
            LocalResource resource = RoleEnvironment.GetLocalResource("MyStorage");
            localStorage.Text = resource.RootPath;
        }
    }
}
