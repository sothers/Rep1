﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;

namespace WebRole1
{
    public partial class StorageAccountBlobs : System.Web.UI.Page
    {
        protected void Page_PreRender(object sender, EventArgs e)
        {
            CloudStorageAccount account = CloudStorageAccount.FromConfigurationSetting("DataConnectionString");

            CloudBlobClient blobClient = account.CreateCloudBlobClient();

            CloudBlobContainer container = blobClient.GetContainerReference("images");

            gridBlob.DataSource = container.ListBlobs();
            gridBlob.DataBind();
        }

        protected void upload_Click(object sender, EventArgs e)
        {
            CloudStorageAccount account = CloudStorageAccount.FromConfigurationSetting("DataConnectionString");

            CloudBlobClient blobClient = account.CreateCloudBlobClient();

            CloudBlobContainer container = blobClient.GetContainerReference("images");

            CloudBlob blob = container.GetBlobReference(imageUpload.FileName);

            blob.UploadFromStream(imageUpload.FileContent);

        }
    }
}