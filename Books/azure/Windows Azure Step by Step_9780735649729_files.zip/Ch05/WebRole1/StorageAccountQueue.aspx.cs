﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;

namespace WebRole1
{
    public partial class StorageAccountQueue : System.Web.UI.Page
    {
        protected void addButton_Click(object sender, EventArgs e)
        {
            var account = CloudStorageAccount.FromConfigurationSetting("DataConnectionString");

            CloudQueueClient queueClient = account.CreateCloudQueueClient();

            CloudQueue queue = queueClient.GetQueueReference("orders");

            CloudQueueMessage m = new CloudQueueMessage(orderTextBox.Text);

            queue.AddMessage(m);
        }

    }
}