﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.WindowsAzure.StorageClient;
using Microsoft.WindowsAzure;

namespace WebRole1
{
    public class MessageServiceContext : TableServiceContext
    {
        public MessageServiceContext(string baseAddress, StorageCredentials credentials) : base(baseAddress, credentials)
        {
        }

        public IQueryable<Message> Messages
        {
            get { return this.CreateQuery<Message>("Messages"); }
        }

        public void AddMessage(string body)
        {
            Message m = new Message();
            m.PartitionKey = "A";
            m.RowKey = Guid.NewGuid().ToString();

            m.Body = body;

            this.AddObject("Messages", m);
            this.SaveChanges();
        }
    }
}

        //public IQueryable<Message> Messages
        //{
        //    get
        //    {
        //        return this.CreateQuery<Message>("Messages");
        //    }
        //}
