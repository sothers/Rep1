﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.WindowsAzure.StorageClient;

namespace WebRole1
{
    public class Message : TableServiceEntity
    {
        public String Body { get; set; }
    }
}