﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.WindowsAzure;

namespace WebRole1
{
    public partial class StorageAccountTable : System.Web.UI.Page
    {
        protected void Page_PreRender(object sender, EventArgs e)
        {
            var account = CloudStorageAccount.FromConfigurationSetting("DataConnectionString");
            var context = new MessageServiceContext(account.TableEndpoint.ToString(), account.Credentials);

            gridTable.DataSource = context.Messages.Take(2);
            gridTable.DataBind();
        }

        protected void addButton_Click(object sender, EventArgs e)
        {
            var account = CloudStorageAccount.FromConfigurationSetting("DataConnectionString");
            var context = new MessageServiceContext(account.TableEndpoint.ToString(), account.Credentials);

            context.AddMessage(messageTextBox.Text);
        }
    }
}