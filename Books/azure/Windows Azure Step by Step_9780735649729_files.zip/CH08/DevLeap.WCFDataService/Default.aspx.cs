﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DevLeap.WCFDataService
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Entities context = new Entities();

            var query = from estate in context.Estates
                        where estate.EstateSold == true
                            && estate.Salesman.SalesmanIsAdmin == true
                        orderby estate.EstateType.EstateTypeDescription
                        select estate.idEstate;

            salemenGrid.DataSource = query.ToList();
            salemenGrid.DataBind();
        }
    }
}
