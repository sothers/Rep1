﻿using System;
using System.Collections.Generic;
using System.Data.Services;
using System.Data.Services.Common;
using System.Linq;
using System.ServiceModel.Web;
using System.Web;
using System.Threading;
using System.Linq.Expressions;

namespace DevLeap.WCFDataService
{
    public class EstatesManagement : DataService<Entities>
    {
        // This method is called only once to initialize service-wide policies.
        public static void InitializeService(DataServiceConfiguration config)
        {
            // TODO: set rules to indicate which entity sets and service operations are visible, updatable, etc.
            // Examples:
            config.SetEntitySetAccessRule("*", EntitySetRights.All);
            config.SetServiceOperationAccessRule("SalesmanAdmin", ServiceOperationRights.All);
            config.DataServiceBehavior.MaxProtocolVersion = DataServiceProtocolVersion.V2;
        }


        [WebGet]
        public IQueryable<Salesman> SalemanAdmin()
        {
            if (!Thread.CurrentPrincipal.IsInRole("Admin"))
                throw new DataServiceException("You cannot access this method");
            
            return this.CurrentDataSource.Salesmen;

        }

        [WebGet]
        public IQueryable<Salesman> SalemanForManager()
        {
            if (!Thread.CurrentPrincipal.IsInRole("Manager"))
                return this.CurrentDataSource.Salesmen.Where(s => s.Estates.Count < 100);

            return this.CreateDataSource().Salesmen;

        }

        [QueryInterceptor("Salesmen")]
        public Expression<Func<Salesman, Boolean>> OnQuerySalemen()
        {
            if (HttpContext.Current.User.Identity.Name.Contains("Roberto"))
                return s => s.SalesmanIsAdmin == false;
            else
                return s => true;
        }

    }
}
