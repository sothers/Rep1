﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;

namespace DevLeap.WCFDataService.ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(@"http://localhost:9138/EstatesManagement.svc/Estates(737)");

            // JSON payload
            string requestPayload = "{EstateAddress:'new highway'}";

            // HTTP MERGE to update
            request.Method = "MERGE";

            UTF8Encoding encoding = new UTF8Encoding();

            request.ContentLength = encoding.GetByteCount(requestPayload);

            request.Credentials = CredentialCache.DefaultCredentials;

            request.Accept = "application/json";
            request.ContentType = "application/json";


            using (Stream requestStream = request.GetRequestStream())
            {
               requestStream.Write(encoding.GetBytes(requestPayload), 0,
                  encoding.GetByteCount(requestPayload));
            }

            try
            {
               // Send the request
               HttpWebResponse response = request.GetResponse() as HttpWebResponse;
               string responseBody = "";

               // Analize the response
               using (Stream rspStm = response.GetResponseStream())
               {
                  using (StreamReader reader = new StreamReader(rspStm))
                  {
                     Console.WriteLine("Response Description: " +
                             response.StatusDescription);
                     Console.WriteLine("Response Status Code: " + 
                             response.StatusCode);
         
                     responseBody = reader.ReadToEnd();

                     Console.WriteLine("Response Body: " +
                        responseBody);
                  }
               }

   
               Console.WriteLine("Status Code: " + 
                   response.StatusCode.ToString());
            }
            catch (System.Net.WebException ex)
            {
               Console.WriteLine("Exception message: " + ex.Message);
               Console.WriteLine("Response Status Code: " + ex.Status);

               // Error details
               StreamReader reader =
                   new StreamReader(ex.Response.GetResponseStream());
                   Console.WriteLine(reader.ReadToEnd());
            }
            
            Console.ReadLine();
        }
    }
}
