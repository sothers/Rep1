﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Services.Client;
using DevLeap.WCFDataService.ConsoleWithServiceReference.ServiceReference;

namespace DevLeap.WCFDataService.ConsoleWithServiceReference
{
    class Program
    {
        static void Main(string[] args)
        {
            Entities ctx = new Entities(new Uri("http://localhost:9138/EstatesManagement.svc"));

            DataServiceQuery<Salesman> query = ctx.CreateQuery<Salesman>("Salesmen");

            foreach(Salesman s in query)
            {
                Console.WriteLine(s.SalesmanDescription);
            }

            Console.ReadLine();


            DataServiceQuery<Salesman> queryInclude = ctx.CreateQuery<Salesman>("Salesmen").Expand("Estates");

            foreach (Salesman s in query)
            {
                Console.WriteLine(s.SalesmanDescription);
                foreach (Estate e in s.Estates)
                {
                    Console.WriteLine(e.EstateDescription);
                }
            }

            Console.ReadLine();

            DataServiceQuery<Salesman> querySingle = ctx.CreateQuery<Salesman>("Salesmen");

            foreach (Salesman s in query)
            {
                Console.WriteLine(s.SalesmanDescription);
                s.SalesmanIsAdmin = false;
            }

            ctx.SaveChanges();

            Console.ReadLine();

            var linqQuery = from salesman in ctx.Salesmen
                            from estate in salesman.Estates
                            where salesman.SalesmanIsAdmin == true
                            orderby estate.EstateEuroPrice descending
                            select new { Dex = estate.EstateDescription };


            foreach (var e in linqQuery)
            {
                Console.WriteLine(e.Dex);
            }

            Console.ReadLine();
        }
    }
}
