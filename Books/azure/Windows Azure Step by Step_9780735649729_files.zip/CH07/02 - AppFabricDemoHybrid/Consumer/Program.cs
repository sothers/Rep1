﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.ServiceBus;
using System.ServiceModel;

namespace Consumer
{
    class Program
    {
        static void Main(string[] args)
        {
            Uri serviceUri = ServiceBusEnvironment.CreateServiceUri("sb", "azuresbs", "HelloService");

            Console.WriteLine("I will send messages to {0}", serviceUri);
            Console.WriteLine();

            ChannelFactory<IHelloChannel> channelFactory = new ChannelFactory<IHelloChannel>("RelayEndpoint", new EndpointAddress(serviceUri));
            IHelloChannel channel = channelFactory.CreateChannel();

            channel.Open();

            IHybridConnectionStatus hybridConnectionStatus = channel.GetProperty<IHybridConnectionStatus>();


            Console.WriteLine("Initial status : {0}", hybridConnectionStatus.ConnectionState);
            Console.WriteLine();

            if (hybridConnectionStatus != null)
            {
                hybridConnectionStatus.ConnectionStateChanged += (o, e) =>
                {
                    Console.WriteLine("Status changed to: {0}.", e.ConnectionState);
                };
            }

            Console.WriteLine("Hello to be sent (or [Enter] to exit):");

            string input = Console.ReadLine();

            while (!String.IsNullOrEmpty(input))
            {
                try
                {
                    Int32 start = Environment.TickCount;
                    String response = channel.SimpleHello(input);
                    Console.WriteLine("Response {0} - Time {1}", response, Environment.TickCount - start);
                }
                catch (Exception e)
                {
                    Console.WriteLine("Error: " + e.Message);
                }

                input = Console.ReadLine();
            }

            channel.Close();
            channel.Dispose();
            channelFactory.Close();
        }
    }
}
