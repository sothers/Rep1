﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using Microsoft.ServiceBus;

namespace Service
{
    class Program
    {
        static void Main(string[] args)
        {
            //Uri address = new Uri("net.tcp://localhost:1234");
            Uri address = ServiceBusEnvironment.CreateServiceUri("sb", "azuresbs", "HelloService");

            Console.WriteLine("Address : " + address);
            Console.WriteLine();

            ServiceHost host = new ServiceHost(typeof(HelloService), address);

            host.Open();


            Console.WriteLine("Press [Enter] to exit");
            Console.ReadLine();

            host.Close();
        }
    }
}
