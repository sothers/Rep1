﻿
using System.ServiceModel;

namespace Service
{

    [ServiceContract(Name = "HelloContract", Namespace = "http://samples.devleap.com/ServiceBus/")]
    public interface IHelloContract
    {
        [OperationContract]
        string SimpleHello(string text);
    }
}
