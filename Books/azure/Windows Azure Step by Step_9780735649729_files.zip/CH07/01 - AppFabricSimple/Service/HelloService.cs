﻿using System;
using System.ServiceModel;

namespace Service
{

    [ServiceBehavior(Name = "HelloService", Namespace = "http://samples.devleap.com/ServiceBus/")]
    public class HelloService : IHelloContract
    {
        public string SimpleHello(string text)
        {
            Console.WriteLine("{0} received", text);
            Console.WriteLine();
            return "I've received : " + text;
        }
    }
}