﻿using System.ServiceModel;

namespace Consumer
{

    [ServiceContract(Name = "HelloContract", Namespace = "http://samples.devleap.com/ServiceBus/")]
    public interface IHelloContract
    {
        [OperationContract]
        string SimpleHello(string text);
    }

    public interface IHelloChannel : IHelloContract, IClientChannel
    {
    }
}