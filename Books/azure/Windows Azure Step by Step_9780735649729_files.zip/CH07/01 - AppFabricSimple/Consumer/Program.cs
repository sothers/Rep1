﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.ServiceBus;
using System.ServiceModel;

namespace Consumer
{
    class Program
    {
        static void Main(string[] args)
        {
            Uri serviceUri = ServiceBusEnvironment.CreateServiceUri("sb", "azuresbs", "HelloService");

            Console.WriteLine("I will send messages to {0}", serviceUri);
            Console.WriteLine();

            ChannelFactory<IHelloChannel> channelFactory = new ChannelFactory<IHelloChannel>("RelayEndpoint", new EndpointAddress(serviceUri));
            IHelloChannel channel = channelFactory.CreateChannel();

            channel.Open();

            Console.WriteLine("Hello to be sent (or [Enter] to exit):");

            string input = Console.ReadLine();

            while (!String.IsNullOrEmpty(input))
            {
                try
                {
                    Console.WriteLine("Reply from the service : {0}", channel.SimpleHello(input));
                    Console.WriteLine();
                }
                catch (Exception e)
                {
                    Console.WriteLine("Error: " + e.Message);
                }

                input = Console.ReadLine();
            }

            channel.Close();
            channel.Dispose();
            channelFactory.Close();
        }
    }
}
